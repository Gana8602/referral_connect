package com.example.referal_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
